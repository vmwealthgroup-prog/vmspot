'use client';
import { useEffect, useState } from 'react';

export default function TradingChart({ symbol = 'BTCUSD' }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:5000/api/chart/${symbol}`)
      .then((res) => res.json())
      .then((data) => setData(data))
      .catch((err) => console.error(err));
  }, [symbol]);

  return (
    <div className="p-4 border border-slate-800 rounded-lg bg-slate-900">
      <h2 className="text-lg font-semibold">{symbol} Live Chart</h2>
      <p className="text-sm text-slate-400">
        Status: {data ? data.status : 'Loading...'}
      </p>
    </div>
  );
}