from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="BTC Engine")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/signals/{symbol}")
def get_btc_signals(symbol: str = "BTCUSD"):
    return {
        "symbol": symbol,
        "signal": "BUY",
        "rsi": 64.5,
        "ema_20": 62400
    }