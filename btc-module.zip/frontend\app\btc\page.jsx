import TradingChart from '@/components/TradingChart';
import StockSearch from '@/components/StockSearch';

export default function BTCPage() {
  return (
    <main className="p-6 bg-slate-950 text-slate-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-4">BTC Trading & Analysis</h1>
      <StockSearch defaultSymbol="BTCUSD" />
      <div className="mt-6">
        <TradingChart symbol="BTCUSD" />
      </div>
    </main>
  );
}